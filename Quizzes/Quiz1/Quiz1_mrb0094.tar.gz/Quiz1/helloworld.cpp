//Matthew Browning
//Quiz1
//This code allows for the text to be printed to the user, such as "Hello world".
//Much help from class

#include <iostream>
using namespace std;

int main() 
{
    cout << "Hello, World!";
        cout << endl;  
	 return 0;
 }
